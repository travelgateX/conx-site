# CON X by TravelgateX

Website for Con-X, the Travel Trade's Symposium.

Annual Conference hold in the beaultiful island of Mallorca, Spain.


--

TravelgateX provides world-class APIs that connect buyers and suppliers across the travel industry. For suppliers, we provide access to the largest network of buyers instantly, saving you time and money. For buyers, you can drive more sales and respond to market changes quickly, all with a single connection.

- __Network__: A single connection to the *largest travel network*.
- __Innovation__: World-class technology with the _most advanced travel APIs_ available.
- __Partnership__: Trusted by _industry leaders_ and _niche providers_ _everywhere_.
